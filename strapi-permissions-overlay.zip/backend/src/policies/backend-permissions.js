// Enforce the custom Backend Role permissions for authenticated Strapi users.
// Public requests continue to use Strapi's Public role permissions.
'use strict';

const MODULE_BY_API = {
  article: 'articles',
  category: 'categories',
  page: 'pages',
  leader: 'leaders',
  department: 'departments',
  'research-institution': 'research_institutions',
  'research-transfer': 'research_transfers',
  supervisor: 'supervisors',
  'student-document': 'student_documents',
  'student-showcase': 'student_showcases',
  'policy-document': 'policy_documents',
  'download-file': 'download_files',
  attachment: 'download_files',
  banner: 'banners',
  link: 'links',
  'site-config': 'site_settings',
  'backend-admin': 'users',
  'backend-role': 'backend_roles',
  'role-permission': 'backend_roles',
  'permission-module': 'backend_roles',
  'permission-action': 'backend_roles',
  'council-intro': 'pages',
  'council-member': 'pages',
};

const getApiName = (ctx) => {
  const route = ctx.state.route || {};
  const handler = typeof route.handler === 'string' ? route.handler : '';
  const match = handler.match(/^api::([^.]*)\./);
  if (match) return match[1];

  const routePath = route.path || ctx._matchedRoute || ctx.path;
  const parts = String(routePath).replace(/^\/api\//, '').split('/');
  return parts[0].replace(/s$/, '');
};

const getRequiredActions = (ctx) => {
  const method = ctx.method.toUpperCase();
  const route = ctx.state.route || {};
  const handler = typeof route.handler === 'string' ? route.handler : '';
  const path = String(route.path || ctx._matchedRoute || ctx.path);
  const actions = [];

  if (method === 'GET' || method === 'HEAD') actions.push('view');
  else if (method === 'POST') actions.push('create');
  else if (method === 'PUT' || method === 'PATCH') actions.push('update');
  else if (method === 'DELETE') actions.push('delete');
  else return null;

  const payload = ctx.request.body && (ctx.request.body.data || ctx.request.body);
  if (/\.publish$/.test(handler) || /\/publish\/?$/.test(path) || payload?.status === 'published') {
    actions.push('publish');
  }
  if (payload && (Object.prototype.hasOwnProperty.call(payload, 'review_status') || /\.review$/.test(handler))) {
    actions.push('review');
  }
  return actions;
};

module.exports = async (ctx, config, { strapi }) => {
  // Anonymous public reads/writes remain controlled by Strapi's Public role.
  const user = ctx.state.user;
  if (!user) return true;

  const email = String(user.email || '').trim().toLowerCase();
  if (!email) return ctx.unauthorized('登录账号缺少邮箱，无法匹配后台权限。');

  const admin = await strapi.db.query('api::backend-admin.backend-admin').findOne({
    where: { email: { $eqi: email } },
    populate: { backend_role: true },
  });
  if (!admin || admin.is_active !== true || !admin.backend_role) {
    return ctx.forbidden('此账号没有有效的后台管理员资料或已停用。');
  }

  const apiName = getApiName(ctx);
  const moduleName = MODULE_BY_API[apiName];
  const actions = getRequiredActions(ctx);
  if (!moduleName || !actions) return ctx.forbidden('此接口未配置后台权限。');

  // These reads are required to restore the authenticated admin's menus and
  // permission settings after login. They expose configuration only.
  if (ctx.method === 'GET' && ['backend-role', 'role-permission', 'permission-module', 'permission-action'].includes(apiName)) {
    return true;
  }

  const roleId = admin.backend_role.id;
  const grants = await strapi.db.query('api::role-permission.role-permission').findMany({
    where: {
      backend_role: { id: roleId },
      permission_module: { name: moduleName, is_active: true },
    },
    populate: { allowed_actions: true },
  });
  const allowed = new Set(grants.flatMap((grant) => (grant.allowed_actions || []).map((item) => item.name)));

  if (apiName === 'backend-admin' && !allowed.has('view')) {
    // The login flow needs the current account's own profile and last_login update.
    if (ctx.method === 'GET' && !ctx.params.id) {
      ctx.query = ctx.query || {};
      ctx.query.filters = { ...(ctx.query.filters || {}), email: { $eq: email } };
      return true;
    }
    if ((ctx.method === 'PUT' || ctx.method === 'PATCH') && ctx.params.id) {
      const ownProfile = await strapi.db.query('api::backend-admin.backend-admin').findOne({
        where: { email: { $eqi: email } },
      });
      const payload = ctx.request.body && (ctx.request.body.data || ctx.request.body);
      const keys = payload && typeof payload === 'object' ? Object.keys(payload) : [];
      if (ownProfile && String(ownProfile.documentId || ownProfile.id) === String(ctx.params.id) && keys.length === 1 && keys[0] === 'last_login') {
        return true;
      }
    }
  }

  if (apiName === 'backend-admin' && ctx.method === 'GET' && ctx.params.id && !allowed.has('view')) {
    const ownProfile = await strapi.db.query('api::backend-admin.backend-admin').findOne({
      where: { email: { $eqi: email } },
    });
    if (ownProfile && String(ownProfile.documentId || ownProfile.id) === String(ctx.params.id)) return true;
  }

  const missing = actions.filter((action) => !allowed.has(action));
  if (missing.length) return ctx.forbidden(`当前后台角色缺少所需权限：${missing.join(', ')}`);
  return true;
};
