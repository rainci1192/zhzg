'use strict';

/**
 * council-intro router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::council-intro.council-intro', {
  config: Object.fromEntries(['find', 'findOne', 'create', 'update', 'delete'].map((action) => [
    action,
    { policies: ['global::backend-permissions'] },
  ])),
});
