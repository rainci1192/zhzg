'use strict';

/**
 * banner router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::banner.banner', {
  config: Object.fromEntries(['find', 'findOne', 'create', 'update', 'delete'].map((action) => [
    action,
    { policies: ['global::backend-permissions'] },
  ])),
});
