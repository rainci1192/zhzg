'use strict';

/**
 * link router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::link.link', {
  config: Object.fromEntries(['find', 'findOne', 'create', 'update', 'delete'].map((action) => [
    action,
    { policies: ['global::backend-permissions'] },
  ])),
});
