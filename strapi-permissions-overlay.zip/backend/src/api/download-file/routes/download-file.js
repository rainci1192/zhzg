'use strict';

/**
 * download-file router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::download-file.download-file', {
  config: Object.fromEntries(['find', 'findOne', 'create', 'update', 'delete'].map((action) => [
    action,
    { policies: ['global::backend-permissions'] },
  ])),
});
