'use strict';

/**
 * permission-module router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::permission-module.permission-module', {
  config: Object.fromEntries(['find', 'findOne', 'create', 'update', 'delete'].map((action) => [
    action,
    { policies: ['global::backend-permissions'] },
  ])),
});
