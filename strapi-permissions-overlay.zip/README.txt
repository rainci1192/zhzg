Strapi 后台角色权限补丁
适用源码版本：rainci1192/zhzg main，提交 b0dd3785d430fbd3609c628c36dfedb3ce8bbcaf

安装
1. 先关闭 Strapi。
2. 在项目目录 E:\zgweb 中备份 backend\src 文件夹。
3. 解压本压缩包到 E:\zgweb，遇到同名文件时选择覆盖。
4. 进入 E:\zgweb\backend，运行 npm run develop。
5. 检查 Strapi 正常启动后，依次测试后台登录、不同角色的查看/新增/编辑/删除权限，以及官网公开页面。

说明
- 给 23 个 Content API 路由增加服务端权限策略，并新增 backend/src/policies/backend-permissions.js。
- 每个已登录 Strapi 用户都必须对应一个有效且启用的 Backend Admin 资料。
- 未登录请求继续由 Strapi Public 角色控制。
- 权限按 Backend Role → Role Permission → Permission Module / Permission Action 检查。
- 为后台登录保留读取角色权限配置，以及读取和更新本人最后登录时间的兼容逻辑。
- 不包含 /api/upload 文件上传接口，也不实施 own/department/custom 数据范围过滤。
- 本补丁只按当前仓库源码生成；安装前请确认本地 backend/src 与上述提交一致。
